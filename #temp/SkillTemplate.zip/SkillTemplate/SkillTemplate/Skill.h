#ifndef SKILL_H
#define SKILL_H
#include "utils/PlayerTask.h"
#include "utils/constants.h"
#include "utils/worldmodel.h"
class Skill {
	Skill() {};
	~Skill() {};
};
#endif
